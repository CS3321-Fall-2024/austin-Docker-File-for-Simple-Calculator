import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

import pytest
from calculator.calculator import (
    squarerootNums,
    cuberootNums,
    factroalNums,
    squareNums,
    triNums,
    lazyCaterer,
    magicSquares,
    run_calculator,
)

@pytest.mark.parametrize("n,expected", [
    (4, 4 * (1/2)),    
    (9, 9 * (1/2)),   
    (16, 16 * (1/2)),  
])
def test_squarerootNums_positive(n, expected):
    assert squarerootNums(n) == expected

def test_squarerootNums_non_positive():
    assert squarerootNums(0) is None
    assert squarerootNums(-4) is None

@pytest.mark.parametrize("n,expected", [
    (27, 27 * (1/3)),   
    (8, 8 * (1/3)),     
    (125, 125 * (1/3)), 
])
def test_cuberootNums_positive(n, expected):
    assert cuberootNums(n) == pytest.approx(expected)

def test_cuberootNums_non_positive():
    assert cuberootNums(0) is None
    assert cuberootNums(-8) is None

def test_factroalNums_non_positive():
    assert factroalNums(0) is None
    assert factroalNums(-1) is None

def test_factroalNums_positive_error():
    with pytest.raises(NameError):
        factroalNums(1)
    with pytest.raises(NameError):
        factroalNums(5)

@pytest.mark.parametrize("n,expected", [
    (2, 4),
    (3, 9),
    (5, 25),
])
def test_squareNums(n, expected):
    assert squareNums(n) == expected

@pytest.mark.parametrize("n,expected", [
    (1, (1 * (1 + 1)) / 2),  # 1
    (2, (2 * (2 + 1)) / 2),  # 3
    (3, (3 * (3 + 1)) / 2),  # 6
])
def test_triNums(n, expected):
    assert triNums(n) == expected

@pytest.mark.parametrize("n,expected", [
    (1, (1**2 + 1 + 2) / 2),  # (1+1+2)/2 = 4/2 = 2
    (2, (2**2 + 2 + 2) / 2),  # (4+2+2)/2 = 8/2 = 4
    (3, (3**2 + 3 + 2) / 2),  # (9+3+2)/2 = 14/2 = 7
])
def test_lazyCaterer(n, expected):
    assert lazyCaterer(n) == expected

@pytest.mark.parametrize("n,expected", [
    (1, (1 * (1**2 + 1)) / 2),  # (1*(1+1))/2 = 1
    (2, (2 * (2**2 + 1)) / 2),  # (2*(4+1))/2 = 5
    (3, (3 * (3**2 + 1)) / 2),  # (3*(9+1))/2 = 15
])
def test_magicSquares(n, expected):
    assert magicSquares(n) == expected

@pytest.mark.parametrize("formula_index, n, expected", [
    (1, 2, squareNums(2)),       # squareNums: 2^2 = 4
    (2, 3, triNums(3)),          # triNums: (3*4)/2 = 6
    (3, 2, lazyCaterer(2)),      # lazyCaterer: (4+2+2)/2 = 4
    (4, 3, magicSquares(3)),     # magicSquares: (3*(9+1))/2 = 15
])
def test_run_calculator_valid(formula_index, n, expected):
    assert run_calculator(formula_index, n) == expected

def test_run_calculator_invalid_index():
    with pytest.raises(IndexError):
        run_calculator(0, 2)
    with pytest.raises(IndexError):
        run_calculator(5, 2)

