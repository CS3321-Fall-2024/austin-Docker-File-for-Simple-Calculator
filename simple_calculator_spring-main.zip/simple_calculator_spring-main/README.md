# Simple Calculator

This program takes a few different inputs and can spit out various results from mathematical formulas.
Your task is to create simple unit tests for each of these formulas.
